#ifndef SR04__H__
#define SR04__H__

void SR04_Startup();
unsigned int SR04_read_raw(unsigned int);
float SR04_read_meters();

#endif // SR04__H__